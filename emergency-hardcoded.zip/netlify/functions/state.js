const { getLatestRecord, putRecord, json, bad } = require('./_jsonbin');

function corsHeaders(){
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, X-Admin-Token',
    'Access-Control-Allow-Methods': 'GET,PUT,OPTIONS',
  };
}

exports.handler = async (event) => {
  try{
    if(event.httpMethod === 'OPTIONS'){
      return { statusCode: 204, headers: corsHeaders(), body: '' };
    }

    if(event.httpMethod === 'GET'){
      const record = await getLatestRecord();
      return json({ ok:true, record }, 200, corsHeaders());
    }

    if(event.httpMethod === 'PUT'){
      const adminToken = process.env.ADMIN_TOKEN;
      if(adminToken){
        const token = event.headers['x-admin-token'] || event.headers['X-Admin-Token'];
        if(token !== adminToken){
          return bad(401, 'Unauthorized (admin token missing/invalid)');
        }
      }

      let body;
      try{ body = JSON.parse(event.body || '{}'); }catch{ return bad(400, 'Invalid JSON body'); }
      if(!body || typeof body !== 'object') return bad(400, 'Body must be JSON object');

      // Expect {record: {...}} or directly {...}
      const record = body.record && typeof body.record === 'object' ? body.record : body;

      await putRecord(record);
      return json({ ok:true }, 200, corsHeaders());
    }

    return bad(405, 'Method not allowed');
  }catch(err){
    return json({ ok:false, error: String(err.message || err) }, 500, corsHeaders());
  }
};
