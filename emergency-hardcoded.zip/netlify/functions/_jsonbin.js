const JSONBIN_BASE = 'https://api.jsonbin.io/v3/b';

const FALLBACK_BIN_ID = '69aca502ae596e708f6ab6d4';
const FALLBACK_MASTER_KEY = '$2a$10$.EkQ6s/7dSu.pEc0ZU6k/eDn2jHGm09FH4YZTj/UhR5dLS5oOOLQO';

function getBinId(){
  return process.env.JSONBIN_BIN_ID || FALLBACK_BIN_ID;
}

function getMasterKey(){
  return process.env.JSONBIN_MASTER_KEY || process.env.JSONBIN_API_KEY || process.env.JSONBIN_X_MASTER_KEY || FALLBACK_MASTER_KEY;
}

async function jsonbinFetch(path, opts = {}){
  const binId = getBinId();
  const key = getMasterKey();
  if(!binId) throw new Error('Missing JSONBin bin id');
  if(!key) throw new Error('Missing JSONBin master key');
  const url = `${JSONBIN_BASE}/${binId}${path}`;

  const headers = {
    'X-Master-Key': key,
    ...(opts.headers || {}),
  };

  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 15000);
  try {
    const res = await fetch(url, {
      ...opts,
      headers,
      signal: ctrl.signal,
    });
    return res;
  } catch (err) {
    throw new Error(`JSONBin network error: ${String(err.message || err)}`);
  } finally {
    clearTimeout(t);
  }
}

async function getLatestRecord(){
  const res = await jsonbinFetch('/latest', { method: 'GET' });
  if(!res.ok){
    const txt = await res.text().catch(()=> '');
    throw new Error(`JSONBin GET latest failed: ${res.status} ${txt}`);
  }
  const data = await res.json();
  return data.record;
}

async function putRecord(record){
  const res = await jsonbinFetch('', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(record),
  });
  if(!res.ok){
    const txt = await res.text().catch(()=> '');
    throw new Error(`JSONBin PUT failed: ${res.status} ${txt}`);
  }
  const data = await res.json();
  return data;
}

function json(body, statusCode = 200, extraHeaders = {}){
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      ...extraHeaders,
    },
    body: JSON.stringify(body),
  };
}

function bad(statusCode, message){
  return json({ ok:false, error: message }, statusCode);
}

module.exports = {
  getLatestRecord,
  putRecord,
  json,
  bad,
};
