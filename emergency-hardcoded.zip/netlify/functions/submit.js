const crypto = require('crypto');
const { getLatestRecord, putRecord, json, bad } = require('./_jsonbin');

function corsHeaders(){
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST,OPTIONS',
  };
}

function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }

exports.handler = async (event) => {
  try{
    if(event.httpMethod === 'OPTIONS'){
      return { statusCode: 204, headers: corsHeaders(), body: '' };
    }
    if(event.httpMethod !== 'POST') return bad(405, 'Method not allowed');

    let body;
    try{ body = JSON.parse(event.body || '{}'); }catch{ return bad(400, 'Invalid JSON'); }

    const { employeeId, name, answer, questionId } = body;
    if(!employeeId || !answer || !questionId){
      return bad(400, 'Missing required fields: employeeId, answer, questionId');
    }

    const maxRetries = 6;
    for(let attempt=0; attempt<maxRetries; attempt++){
      const state = await getLatestRecord();

      if(!state.currentQuestion || state.currentQuestion.id !== questionId){
        return json({ ok:false, error:'Question is not active' }, 200, corsHeaders());
      }

      state.submissions = (state.submissions && typeof state.submissions === 'object' && !Array.isArray(state.submissions)) ? state.submissions : {};
      // One attempt per employee per question (even across multiple phones / browsers)
      const already = Object.values(state.submissions).some(s =>
        String(s.employeeId) === String(employeeId) && String(s.questionId) === String(questionId)
      );
    if(already){
  return json({ ok:true, already:true }, 200, corsHeaders());
}

      const subId = 'sub_' + (crypto.randomUUID ? crypto.randomUUID() : (Date.now() + '_' + Math.random().toString(36).slice(2)));
      state.submissions[subId] = {
        id: subId,
        employeeId: String(employeeId),
        name: String(name || ''),
        answer: String(answer),
        questionId: String(questionId),
        timestamp: Date.now(), // SERVER timestamp
      };

      try{
        await putRecord(state);
        return json({ ok:true, submissionId: subId }, 200, corsHeaders());
      }catch(e){
        const msg = String(e.message || e);
        // Backoff on rate limit / transient failures
        if(msg.includes('429') || msg.includes('502') || msg.includes('503') || msg.includes('504')){
          await sleep(250 * (attempt + 1));
          continue;
        }
        // If unknown error, surface it
        return json({ ok:false, error: msg }, 500, corsHeaders());
      }
    }

    return bad(503, 'Too busy, please try again');
  }catch(err){
    return json({ ok:false, error: String(err.message || err) }, 500, corsHeaders());
  }
};
