const JSONBIN_BASE = 'https://api.jsonbin.io/v3/b';

function requireEnv(name){
  const v = process.env[name];
  if(!v) throw new Error(`Missing env var: ${name}`);
  return v;
}

async function jsonbinFetch(path, opts = {}){
  const binId = requireEnv('JSONBIN_BIN_ID');
  const key = requireEnv('JSONBIN_MASTER_KEY');
  const url = `${JSONBIN_BASE}/${binId}${path}`;

  const headers = {
    'X-Master-Key': key,
    ...(opts.headers || {}),
  };

  const res = await fetch(url, {
    ...opts,
    headers,
  });

  return res;
}

async function getLatestRecord(){
  const res = await jsonbinFetch('/latest', { method: 'GET' });
  if(!res.ok){
    const txt = await res.text().catch(()=> '');
    throw new Error(`JSONBin GET latest failed: ${res.status} ${txt}`);
  }
  const data = await res.json();
  return data.record;
}

async function putRecord(record){
  const res = await jsonbinFetch('', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(record),
  });
  if(!res.ok){
    const txt = await res.text().catch(()=> '');
    throw new Error(`JSONBin PUT failed: ${res.status} ${txt}`);
  }
  const data = await res.json();
  return data;
}

function json(body, statusCode = 200, extraHeaders = {}){
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      ...extraHeaders,
    },
    body: JSON.stringify(body),
  };
}

function bad(statusCode, message){
  return json({ ok:false, error: message }, statusCode);
}

module.exports = {
  getLatestRecord,
  putRecord,
  json,
  bad,
};
